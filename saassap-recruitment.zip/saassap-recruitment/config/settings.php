<?php
//website url 
 /**
 * Include the trailing slash on the domain  /
 */
 define('URL', "http://localhost/saassap-recruitment/");
 //mode
 define('SITE_MODE', 'debug',true);
 //site name
 define('SITE_NAME', 'Saassap-recruitment');
 
