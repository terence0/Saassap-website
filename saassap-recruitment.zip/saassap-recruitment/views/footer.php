		<!-- <footer class="ftco-footer ftco-bg-dark ftco-section"> -->
		<br/><br/><br/>
		  <div class="container">
		    <!-- <div class="row mb-5">-->
		      <!-- <div class="col-md-6 col-lg-3"> -->
		        <!-- <div class="ftco-footer-widget mb-5">
		          <h2 class="ftco-heading-2">Have a Questions?</h2>
		          <div class="block-23 mb-3">
		            <ul>
		              <li><span class="icon icon-map-marker"></span><span class="text">16 & 18 Fisher Avenue,
		                  Epping 1,
		                  Cape Town,
		                  7475</span></li>
					  <li><a href="#"><span class="icon icon-phone"></span><span class="text"> +27(0)78 343 7396<br/>
					
					  National: 087 077 0506</span></a></li>
		              <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info@leopardmovers.co.za</span></a></li>
		            </ul>
		          </div> -->
		          <!-- <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3"> -->
		            <!-- <li class="ftco-animate"><a href="https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Fleopardfurnitureremovals.co.za%2F&ref_src=twsrc%5Etfw&text=Home&tw_p=tweetbutton&url=https%3A%2F%2Fleopardfurnitureremovals.co.za%2F&via=leopardmovers"><span class="icon-twitter"></span></a></li>
		            <li class="ftco-animate"><a href="https://www.facebook.com/sharer/sharer.php?kid_directed_site=0&sdk=joey&u=https%3A%2F%2Fleopardfurnitureremovals.co.za%2F&display=popup&ref=plugin&src=share_button"><span class="icon-facebook"></span></a></li>
		            <li class="ftco-animate"><a href="https://www.instagram.com/explore/locations/286495711377772/leopard-movers/"><span class="icon-instagram"></span></a></li>
		          </ul>
		        </div>
		      </div> -->
		      <!-- <div class="col-md-6 col-lg-2">
		        <div class="ftco-footer-widget mb-5 ml-md-4">
		          <h2 class="ftco-heading-2">Links</h2>
		          <ul class="list-unstyled">
		            <li><a href="home"><span class="ion-ios-arrow-round-forward mr-2"></span>Home</a></li>
		            <li><a href="about-us"><span class="ion-ios-arrow-round-forward mr-2"></span>About</a></li>
		            <li><a href="services"><span class="ion-ios-arrow-round-forward mr-2"></span>Services</a></li>
		            <li><a href="gallery"><span class="ion-ios-arrow-round-forward mr-2"></span>Gallery</a></li>
		            <li><a href="contact-us"><span class="ion-ios-arrow-round-forward mr-2"></span>Contact</a></li>
		          </ul>
		        </div>
		      </div> -->
		      <!-- <div class="col-md-6 col-lg-4">
		        <div class="ftco-footer-widget mb-5">
		          <h2 class="ftco-heading-2">Recent Blog</h2>
		          <div class="block-21 mb-4 d-flex">
		            <a class="blog-img mr-4" style="background-image: url(images/image_1.jpg);"></a>
		            <div class="text">
		              <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control about</a></h3>
		              <div class="meta">
		                <div><a href="#"><span class="icon-calendar"></span> Oct. 16, 2019</a></div>
		                <div><a href="#"><span class="icon-person"></span> Admin</a></div>
		                <div><a href="#"><span class="icon-chat"></span> 19</a></div>
		              </div>
		            </div>
		          </div>
		          <div class="block-21 mb-5 d-flex">
		            <a class="blog-img mr-4" style="background-image: url(images/image_2.jpg);"></a>
		            <div class="text">
		              <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control about</a></h3>
		              <div class="meta">
		                <div><a href="#"><span class="icon-calendar"></span> Oct. 16, 2019</a></div>
		                <div><a href="#"><span class="icon-person"></span> Admin</a></div>
		                <div><a href="#"><span class="icon-chat"></span> 19</a></div>
		              </div>
		            </div>
		          </div>
		        </div>
		      </div> -->
		      <!-- <div class="col-md-6 col-lg-3 centre ">
		        <div class="ftco-footer-widget mb-5">
		          <h2 class="ftco-heading-2">Subscribe Us!</h2>
		          <form action="public/mail/subscribe.php" method="POST" class="subscribe_form subscribe-form">
		            <div class="form-group">
		              <input type="email" class="form-control mb-2 text-center" required name="subemail" id="subemail" placeholder="Enter email address">
		              <input type="submit" value="Subscribe" class="form-control submit px-3">
		            </div>
                            <div class="g-recaptcha"
      data-sitekey="6LfRuPcUAAAAADtrlUew079UStKZ5gt71Lq3dfMN"
      data-callback="onSubmit"
      data-size="invisible">
</div>
			<div class="subscribe__msg">

</div> -->
		          <!-- </form>
		        </div>
		      </div>
		    </div> -->
		    <div class="row">
		      <div class="col-md-12 text-center">

		        <p>
		          <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
		          Copyright &copy;<script>
		            document.write(new Date().getFullYear());
		          </script> SAASSAP | Reg. 2020/914608/08. All rights reserved | Developed by ReBeA Nation Tech
		          <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
		        </p>
		      </div>
		    </div>
		  </div>
		<!-- </footer> -->



		<!-- loader -->
		<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
		    <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
		    <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" /></svg></div>


		<script src="public/js/jquery.min.js"></script>
		<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="public/js/jquery-migrate-3.0.1.min.js"></script>
		<script src="public/js/popper.min.js"></script>
		<script src="public/js/bootstrap.min.js"></script>
		<script src="public/js/jquery.easing.1.3.js"></script>
		<script src="public/js/jquery.waypoints.min.js"></script>
		<script src="public/js/jquery.stellar.min.js"></script>
		<script src="public/js/owl.carousel.min.js"></script>
		<script src="public/js/jquery.magnific-popup.min.js"></script>
		<script src="public/js/aos.js"></script>
		<script src="public/js/jquery.animateNumber.min.js"></script>
		<script src="public/js/scrollax.min.js"></script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
		<script src="public/js/google-map.js"></script>
		<script src="public/js/main.js"></script>
		<script src="public/js/fieldAdditionQualifications.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="public/js/app.js"></script>
		<script src="public/mail/mover.js"></script>
		<script src="public/mail/contact.js"></script>
		<script src="public/mail/load.js"></script>
		<script src="public/mail/subscribe.js"></script> 
                <script src="https://www.google.com/recaptcha/api.js" async defer></script>

		</body>

		</html>
