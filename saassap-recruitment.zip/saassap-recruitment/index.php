<?php

require 'config/config.php';


$app = new Bootstrap();
$app->init();
